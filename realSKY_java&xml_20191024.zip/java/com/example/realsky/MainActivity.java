package com.example.realsky;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.realsky.ui.add.AddFragment;
import com.example.realsky.ui.commu.CommuFragment;
import com.example.realsky.ui.home.HomeFragment;
import com.example.realsky.ui.mypage.MypageFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {


    private FragmentManager fragmentManager = getSupportFragmentManager();
    private HomeFragment fragmentHome = new HomeFragment();
    private CommuFragment fragmentCommu = new CommuFragment();
    private MypageFragment fragmentMypage = new MypageFragment();
    private AddFragment fragmentAdd = new AddFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_login);
        setContentView(R.layout.activity_main);


        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.nav_host_fragment, fragmentHome).commitAllowingStateLoss();

        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(new ItemSelectedListener());

//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                // handle desired action here
//                // One possibility of action is to replace the contents above the nav bar
//                // return true if you want the item to be displayed as the selected item
//                return true;
//            }
//        });

    }

    class ItemSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener{
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();

            switch(menuItem.getItemId())
            {
                case R.id.homeItem:
                    transaction.replace(R.id.nav_host_fragment, fragmentHome).commitAllowingStateLoss();
//                    setContentView(R.layout.fragment_home);
                    return true;
                case R.id.commuItem:
                    transaction.replace(R.id.nav_host_fragment, fragmentCommu).commitAllowingStateLoss();
//                    setContentView(R.layout.fragment_commu);
                    return true;
                case R.id.mypageItem:
                    transaction.replace(R.id.nav_host_fragment, fragmentMypage).commitAllowingStateLoss();
//                    setContentView(R.layout.fragment_mypage);
                    return true;
                case R.id.addItem:
                    transaction.replace(R.id.nav_host_fragment, fragmentAdd).commitAllowingStateLoss();
//                    setContentView(R.layout.fragment_add);
                    return true;
            }
            return false;
        }
    }
}

//public class MainActivity extends AppCompatActivity {
//
//    Fragment HomeFragment;
//    Fragment CommuFragment;
//    Fragment MypageFragment;
//    Fragment AddFragment;
//
//    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
//        @Override
//        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
//            switch (menuItem.getItemId()){
//                case R.id.homeItem:
//                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,HomeFragment).commit();
//                    return true;
//                case R.id.commuItem:
//                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,CommuFragment).commit();
//                    return true;
//                case R.id.mypageItem:
//                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,MypageFragment).commit();
//                    return true;
//                case R.id.addItem:
//                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,AddFragment).commit();
//                    return true;
//            }
//            return false;
//        }
//    };
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_login);
//        setContentView(R.layout.activity_main);
//
//        BottomNavigationView navView = findViewById(R.id.nav_view);
//        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
//
//        HomeFragment = new HomeFragment();
//        CommuFragment = new CommuFragment();
//        MypageFragment = new MypageFragment();
//        AddFragment = new AddFragment();
//
//        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,HomeFragment).commit();
//
//    }
//
//}