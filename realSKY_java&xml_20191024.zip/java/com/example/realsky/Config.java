package com.example.realsky;

public class Config {
    // 서버 통신을 위한 변수 선언
    public static final String TAG = "DBQuery";
    public static final String IP_ADDRESS = "10.20.15.12/realSKY/";
    public static final String TAG_JSON="REAL_SKY";
    public static final String TAG_ID = "Id";
    public static final String TAG_PASSWORD = "Password";
    public static final String IMAGE_DIRECTORY_NAME = "AndroidFileUpload";
}