package com.example.realsky;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import static com.example.realsky.Config.IP_ADDRESS;
import static com.example.realsky.Config.TAG;
import static com.example.realsky.Config.TAG_ID;
import static com.example.realsky.Config.TAG_JSON;
import static com.example.realsky.Config.TAG_PASSWORD;

public class LoginActivity extends AppCompatActivity {
    // 임시 로그인에 사용할 변수를 선언
    private final String root = "root";
    private final String pw = "0000";
    // 사용할 Button 변수들
    Button loginButton;
    // EditText 변수 선언 : id, password textView;
    EditText idText;
    EditText passwordText;
    // TextView 지만 Button 처럼 사용할 것
    TextView registerButton;
    TextView idSearchButton;
    TextView passwordSearchButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 변수 연결
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.RegisterButton);
        idText = findViewById(R.id.idEditText);
        passwordText = findViewById(R.id.passwordEditText);
        idSearchButton = findViewById(R.id.IdSearchButton);
        passwordSearchButton = findViewById(R.id.PasswordSearchButton);
        // debug용 아이디 비밀번호 자동 입력.
        idText.setText(root);
        passwordText.setText(pw);

        // Login Button Event
        loginButton.setOnClickListener(new View.OnClickListener()   {
            @Override
            public void onClick (View view) {
                // 아이디 비밀번호 확인
                if(idText.getText().toString().contentEquals(root) && passwordText.getText().toString().contentEquals(pw)) {
                    /*
                    서버와의 데이터 확인 후 로그인 여부 결정
                     */
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                } else {
                    InsertData insertData = new InsertData();
                    insertData.execute(idText.getText().toString(), passwordText.getText().toString());
                }


            }
        });

        // Register Button Event
        registerButton.setOnClickListener(new View.OnClickListener()    {
            @Override
            public void onClick (View view){
            Intent intent = new Intent(getApplicationContext(), Register1Activity.class); // 다음 넘어갈 클래스 지정
            startActivity(intent); // 다음 화면으로 넘어간다
        }});

        // search Butto Event
        idSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), IDSearchActivity.class));
            }
        });

        passwordSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PWSearchActivity.class));
            }
        });
    }

    /*
    서버 통신을 위한 클래스
    To get id and password from mysql server, it connect to php server; provided by jsh.
    IP_ADDRESS is not constant, so every time it runt check IP_ADDRESS.
     */
    private class InsertData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(LoginActivity.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "response - " + result);

            showResult(result);
        }

        @Override
        protected String doInBackground(String... params) {
            // get parameters
            String idParameter = params[0];
            String pwParameter = params[1];
            // encode password with SHA-256
            try {
                StringBuilder sb;
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(pwParameter.getBytes());
                sb = new StringBuilder();
                for(byte b : md.digest())
                    sb.append(String.format("%02x", b));
                pwParameter = sb.toString();
            } catch (NoSuchAlgorithmException e) {
                Log.d(TAG, "NoSuchAlgorithmException : " + e.getMessage());
            }
            // set serverURL and post parameter. use id only cuz id & password are pair
            String serverURL = "http://"+IP_ADDRESS+"loginQuery.php";
            String postParameter = "id=" + idParameter + "&password=" + pwParameter;

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();

                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameter.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }
                bufferedReader.close();

                return sb.toString().trim();
            } catch (Exception e) {
                Log.d(TAG, "InsertData: Error ", e);
                errorString = e.toString();
                return null;
            }

        }
        private void showResult(String result){
            if(result.startsWith("{")) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);
                    JSONObject item = jsonArray.getJSONObject(0);

                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                } catch (JSONException e) {
                    Log.d(TAG, "showResult : ", e);
                    Toast.makeText(getApplicationContext(), "서버 통신 오류!", Toast.LENGTH_LONG).show();
                } catch (NullPointerException f) {
                    Log.d(TAG, "showResult : ", f);
                    Toast.makeText(getApplicationContext(), "아이디와 비밀번호를 확인해 주세요.", Toast.LENGTH_LONG).show();
                }
            }
            else {
                Toast.makeText(getApplicationContext(), "등록되지 않은 아이디 입니다.", Toast.LENGTH_LONG).show();
            }

        }
    }
}
