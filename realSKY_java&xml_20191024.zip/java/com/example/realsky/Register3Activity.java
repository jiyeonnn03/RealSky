package com.example.realsky;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import static com.example.realsky.Config.IP_ADDRESS;
import static com.example.realsky.Config.TAG;

/*
서버와 통신할 때 파라미터 순서
1. 사용할 php 파일 이름
2. name
3. nickname
4. id
5. password
 */

public class Register3Activity extends AppCompatActivity {
    // Button 변수
    Button nicknameCheckButton;
    Button idCheckButton;
    Button finishButton;
    ImageView exitButton;   // register2, 3은 imageView 로 되어 있다.
    // EditText 변수
    EditText nameText;
    EditText nicknameText;
    EditText idText;
    EditText passwordText;
    EditText passwordCheckText;
    // 서버 통신에 사용할 변수
    boolean query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register3);

        // 변수 연결
        nicknameCheckButton = findViewById(R.id.nicknameCheckButton);
        idCheckButton = findViewById(R.id.idCheckButton);
        finishButton = findViewById(R.id.register3NextButton);
        exitButton = findViewById(R.id.register3ExitButton);
        nameText = findViewById(R.id.nameEditText);
        nicknameText = findViewById(R.id.nicknameEditText);
        idText = findViewById(R.id.idEditText);
        passwordText = findViewById(R.id.passwordEditText);
        passwordCheckText = findViewById(R.id.passwordCheckEditText);
        // 닉네임 중복확인 -> EditText 비활성화
        nicknameCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                query=true;
                InsertData insertData = new InsertData();
                insertData.execute("overlapQuery.php", "Nickname", nicknameText.getText().toString(), null, null);

                StringBuilder sb = new StringBuilder();
                AlertDialog.Builder builder = new AlertDialog.Builder(Register3Activity.this);
                int resultInt;
                try {
                    resultInt = Integer.parseInt(insertData.resultFromServer);
                    if( resultInt == 0) {
                        sb.append("'"+nicknameText.getText().toString() + "'은 사용 가능한 닉네임입니다.\n사용하시겠습니까?");
                        builder.setMessage(sb.toString()).setTitle("닉네임 중복확인");
                        builder.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // do nothing
                            }
                        });
                        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                nicknameText.setFocusable(false);
                                nicknameCheckButton.setFocusable(false);
                            }
                        });
                    } else {
                        sb.append("'"+nicknameText.getText().toString() + "'은 사용 불가능한 닉네임입니다.");
                        builder.setMessage(sb.toString()).setTitle("닉네임 중복확인").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // do nothing
                            }
                        });
                    }
                } catch (NumberFormatException e) {
                    Log.d("NumberFormatException", e.getMessage());
                    sb.append("Server Connection Error!");
                    builder.setMessage(sb.toString()).setTitle("닉네임 중복확인").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            // do nothing
                        }
                    });
                }
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
        // 아이디 중복확인 -> EditText 비활성화
        idCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                query=true;
                InsertData insertData = new InsertData();
                insertData.execute("overlapQuery.php", "Id", idText.getText().toString());
                StringBuilder sb = new StringBuilder();
                AlertDialog.Builder builder = new AlertDialog.Builder(Register3Activity.this);
                int resultInt;
                try {
                    resultInt = Integer.parseInt(insertData.resultFromServer);
                    if( resultInt == 0) {
                        sb.append("'"+idText.getText().toString() + "'은 사용 가능한 아이디입니다.\n사용하시겠습니까?");
                        builder.setMessage(sb.toString()).setTitle("아이디 중복확인");
                        builder.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // do nothing
                            }
                        });
                        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                idText.setFocusable(false);
                                idCheckButton.setFocusable(false);
                            }
                        });
                    } else {
                        sb.append("'"+idText.getText().toString() + "'은 사용 불가능한 아이디입니다.");
                        builder.setMessage(sb.toString()).setTitle("아이디 중복확인").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // do nothing
                            }
                        });
                    }
                } catch (NumberFormatException e) {
                    Log.d("NumberFormatException", e.getMessage());
                    sb.append("Server Connection Error!");
                    builder.setMessage(sb.toString()).setTitle("아이디 중복확인").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            // do nothing
                        }
                    });
                }
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
        // 확인 버튼 이벤트(비밀번호 일치 확인, 빈칸 있나 확인
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                query=false;
                /*
                파라미터 정리
                1. php 파일 이름
                2. name
                3. id
                4. password (암호화 전)
                5. nickname
                */
                if(passwordText.getText().toString().contentEquals(passwordCheckText.getText().toString()) &&
                !nicknameText.isFocusable() && !idText.isFocusable()) {
                    InsertData insertData = new InsertData();
                    insertData.execute("insert.php", nameText.getText().toString(), idText.getText().toString(), passwordText.getText().toString(), nicknameText.getText().toString());
                    int resultInt;
                    try {
                        resultInt = Integer.parseInt(insertData.resultFromServer);
                        if(resultInt == 0) {
                            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(intent);

                            Toast.makeText(getApplicationContext(), insertData.resultFromServer, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Error Code : "+resultInt, Toast.LENGTH_LONG).show();
                        }
                    } catch (NumberFormatException e) {
                        Log.d("NumberFormatException", e.getMessage());
                    }
                } else if (nicknameText.isFocusable()) {
                    Toast.makeText(getApplicationContext(), "닉네임 중복확인을 해주십시오.", Toast.LENGTH_LONG).show();
                } else if (idText.isFocusable()) {
                    Toast.makeText(getApplicationContext(), "아이디 중복확인을 해주십시오.", Toast.LENGTH_LONG).show();
                } else
                    Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.", Toast.LENGTH_LONG).show();
            }
        });
        // X 버튼 이벤트
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view){
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    /*
    회원가입시 입력한 정보를 서버에 보내는 클래스
     */
    private class InsertData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;
        String resultFromServer;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(Register3Activity.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "POST response  - " + result);
        }

        @Override
        protected String doInBackground(String... params) {
            /*
            파라미터 정리
            if query == true
            0. php 파일 이름
            1. criterion
            2. data
            else
            0. php 파일 이름
            1. name
            2. id
            3. password
            4. nickname
             */
            String postParameters;
            String fileName = params[0];
            if(query) {
                postParameters = "criterion=" + params[1] + "&data=" + params[2];
            } else {
                /*
                비밀번호를 SHA-256으로 변경
                 */
                String password = params[3];
                StringBuilder sb;
                try {
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    md.update(password.getBytes());
                    sb = new StringBuilder();
                    for(byte b : md.digest())
                        sb.append(String.format("%02x", b));
                    password = sb.toString();
                } catch (NoSuchAlgorithmException e) {
                    Log.d(TAG, "NoSuchAlgorithmException : " + e.getMessage());
                }
                postParameters = "name=" + params[1] + "&id=" + params[2] + "&password=" + password + "&nickname=" + params[4];
            }

            try {
                URL url = new URL("http://"+IP_ADDRESS + fileName);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.connect();

                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }
                bufferedReader.close();

                resultFromServer = sb.toString();
                return sb.toString();
            } catch (Exception e) {
                Log.d(TAG, "InsertData: Error ", e);
                return new String("Error: " + e.getMessage());
            }
        }
    }
}
