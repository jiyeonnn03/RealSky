package com.example.realsky.ui.add;

import androidx.lifecycle.ViewModel;

public class AddViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
