package com.example.realsky.ui;

import androidx.lifecycle.ViewModel;

public class EmptyViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
