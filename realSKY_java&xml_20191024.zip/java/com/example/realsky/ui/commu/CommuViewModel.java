package com.example.realsky.ui.commu;

import androidx.lifecycle.ViewModel;

public class CommuViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
