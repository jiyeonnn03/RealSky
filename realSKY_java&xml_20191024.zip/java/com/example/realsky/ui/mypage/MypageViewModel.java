package com.example.realsky.ui.mypage;

import androidx.lifecycle.ViewModel;

public class MypageViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
