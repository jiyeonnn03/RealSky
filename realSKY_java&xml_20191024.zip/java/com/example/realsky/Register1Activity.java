package com.example.realsky;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import android.widget.ImageButton;
import android.widget.Toast;

public class Register1Activity extends AppCompatActivity {
    // CheckBox 변수 선언
    CheckBox allCheckBox;
    CheckBox checkBox1;
    CheckBox checkBox2;
    CheckBox checkBox3;
    CheckBox checkBox4;
    // Button 변수 선언
    Button nextButton;
    ImageButton exitButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register1);

        // 변수 연결
        allCheckBox = findViewById(R.id.약관전체동의);
        checkBox1 = findViewById(R.id.서비스이용약관);
        checkBox2 = findViewById(R.id.개인정보수집이용동의);
        checkBox3 = findViewById(R.id.수집한개인정보의제3자정보제공동의);
        checkBox4 = findViewById(R.id.위치기반서비스이용약관에동의);
        nextButton = findViewById(R.id.register1NextButton);
        exitButton = findViewById(R.id.register1ExitButton);

        // 전체 약관동의시 모두 체크
        allCheckBox.setOnClickListener(new CheckBox.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(allCheckBox.isChecked()) {
                    checkBox1.setChecked(true);
                    checkBox2.setChecked(true);
                    checkBox3.setChecked(true);
                    checkBox4.setChecked(true);
                }
                else {
                    checkBox1.setChecked(false);
                    checkBox2.setChecked(false);
                    checkBox3.setChecked(false);
                    checkBox4.setChecked(false);
                }
            }
        });

        // 약관중 하나라도 체크 해제시 전체약관동의 해제
        View.OnClickListener isAllCheckedListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!checkBox1.isChecked() || !checkBox2.isChecked() || !checkBox3.isChecked() || !checkBox4.isChecked())
                    allCheckBox.setChecked(false);
                else if (checkBox1.isChecked() && checkBox2.isChecked() && checkBox3.isChecked() && checkBox4.isChecked())
                    allCheckBox.setChecked(true);
            }
        };
        checkBox1.setOnClickListener(isAllCheckedListener);
        checkBox2.setOnClickListener(isAllCheckedListener);
        checkBox3.setOnClickListener(isAllCheckedListener);
        checkBox4.setOnClickListener(isAllCheckedListener);

        // 확인 버튼 이벤트
        nextButton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 참고 : allCheckBox에 대한 예외처리 완료. allCheckBox에 check만 검사하고 넘어가도 된다.
                if(allCheckBox.isChecked()) {
                    Intent intent = new Intent(getApplicationContext(), Register2Activity.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(getApplicationContext(), "모든 이용약관에 동의해야 넘어갈 수 있습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        // X 버튼 이벤트
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent2);
            }
        });



    }
}